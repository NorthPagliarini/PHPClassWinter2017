<?php
$username = "shop";
$password = "se266";
$dsn = "mysql:host=localhost; dbname=my_guitar_shop1";
$db = new PDO($dsn, $username, $password);
?>